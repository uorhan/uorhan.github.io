function [Cts,kk]  = pTestGPU(TS_Amb, TS_Namb, X)
    for n=1:size(TS_Amb,2)
        TS_Amb(TS_Amb(:,n)==0,n) =  TS_Amb(TS_Amb(:,n)==0,1);
    end
    D = gpuArray(zeros(size(TS_Amb,1),size(TS_Amb,2)));
    for n=1:size(TS_Amb,2)
        for m=1:size(TS_Namb,2)
            D(:,n) = D(:,n) + (sum((X(TS_Amb(:,n),:) - X(TS_Namb(:,m),:)).^2,2)).^0.5;
        end
    end
    [~,kk] = min(D,[],2);
    Cts = sum(kk == 1) / size(TS_Amb,1);