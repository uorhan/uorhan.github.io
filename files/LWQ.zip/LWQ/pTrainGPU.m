    X = mX;
    Ctr(i) = 0;
    [L,N] = size(X);
    f = 0;
    f2 = 0;
    for rR=1:TKR
        %X = (1 - 2 * rand(size(mX,1),N)) + mX;
        for n=1:size(Amb,2)
            Amb(Amb(:,n)==0,n) =  Amb(Amb(:,n)==0,1);
        end
        while 1==1
            D = gpuArray(zeros(size(Amb,1),size(Amb,2)));
            for n=1:size(Amb,2)
                for m=1:size(Namb,2)
                    D(:,n) = D(:,n) + (sum((X(Amb(:,n),:) - X(Namb(:,m),:)).^2,2)).^0.5;
                end
            end
            if sum(isinf(D(:))) > 0
                eta = eta / 10;
                X = mX;
                %fprintf('INF value is found!');
            else
                break;
            end
        end
        [~,kk] = min(D,[],2);
        C  = sum(kk == 1) / size(Amb,1);
        [C2,KK] = pTestGPU(TS_Amb, TS_Namb, X);
%         plot(mX(:,1),mX(:,2),'b.');
%         axis([0 1 0 1]);
%         pause;        
        for n=1:size(Amb,2)
            for m=1:size(Namb,2)
                if n==1
                    delta = repmat(eta * (0.01+(kk>1)),1,N) .* (X(Namb(:,m),:) - X(Amb(:,n),:));
                    %delta = repmat(eta * (kk>1),1,N) .* (X(Namb(:,m),:) - X(Amb(:,n),:));
                    [xx, yy] = ndgrid(Namb(:,m),1:N);
                    dY = accumarray([xx(:) yy(:)],delta(:));
                    dY = [dY; zeros(L - size(dY,1),N)];
                    X = X - dY;

                    [xx, yy] = ndgrid(Amb(:,n),1:N);
                    dY = accumarray([xx(:) yy(:)],delta(:));
                    dY = [dY; zeros(L - size(dY,1),N)];
                    X = X + dY;
                else
                    delta = repmat(eta * (0.01+(kk>1)),1,N) .* (X(Namb(:,m),:) - X(Amb(:,n),:));
                    %delta = repmat(eta * (kk>1),1,N) .* (X(Namb(:,m),:) - X(Amb(:,n),:));
                    delta = delta(Amb(:,n)~=Amb(:,1),:);
                    [xx, yy] = ndgrid(Namb(Amb(:,n)~=Amb(:,1),m),1:N);
                    dY = accumarray([xx(:) yy(:)],delta(:));
                    dY = [dY; zeros(L - size(dY,1),N)];
                    X = X + dY;

                    [xx, yy] = ndgrid(Amb(Amb(:,n)~=Amb(:,1),n),1:N);
                    dY = accumarray([xx(:) yy(:)],delta(:));
                    dY = [dY; zeros(L - size(dY,1),N)];
                    X = X - dY;
                end
            end
        end
        
%         X = X - repmat(min(X),size(X,1),1);
%         X = X ./ repmat(max(X),size(X,1),1);

        if C > Ctr(i)
%             fprintf('rR %d eta %2.10f TR %2.2f TS %2.2f\n',rR,eta,100*C,100*C2);
            Ctr(i) = C;
            Cts(i) = C2;
            mX = X;
            f  = 0;
            f2 = 0;
            if C > 0.7 && C2 == 1
                break
            end
        else
            f = f + 1;
            %X = (1 - 2 * rand(size(mX,1),N)) + X;
            if f > 2
                %X = mX;
                eta = eta / 2;
                f = 0;
                f2 = f2 + 1;
                if f2 > 9
                    break;
                end
            end
        end
    end