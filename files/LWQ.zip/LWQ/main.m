function main(N, p)
%
g = gpuDevice(2);
g.reset();
%clc;

if exist(['KKtestP' num2str(p) 'N' num2str(N) '.mat'])~=2
    save(['KKtestP' num2str(p) 'N' num2str(N) '.mat'], 'p', 'N');
end
warning off;
for tekrar=1:100
    load(['DATAp' num2str(p) '.mat']);
    B = gpuArray(unique(single(B),'rows'));
    %B = B2 - 1;

    Sh       = 0;
    TKR      = gpuArray(10000);
    Eta      = gpuArray(0.001);
    Fold     = 2;

    %S�n�f de�eri tek olan sat�rlara temizlik
    % A = B(:,p+1:end);
    % [ii,~,kk] = unique(A(:),'rows','stable');
    % out = sortrows([accumarray(kk,1),ii]);
    % sil = out(out(:,1)==1,2);
    % D = dist(B(:,p+1),sil'); 
    % B(logical(sum(D==0,2)),:) = [];
    % silN = sum(sum(D==0,2));
    V2 = ['';V];
    Cts = gpuArray(zeros(Fold,1));
    Ctr = gpuArray(zeros(Fold,1));

    gN  = gpuArray(N);
    Len = gpuArray(max(B(:)));
    ALL_Namb = B(:,1:p);
    ALL_Amb  = B(:,p+1:end);
    CVO = cvpartition(gather(ALL_Amb(:,1)),'k',Fold);
    %load('kfold.mat');
    RS = [];
    for i = 1:CVO.NumTestSets
        eta   = Eta;
        mX    = gpuArray.rand(max(B(:)),N);
        f     = 0;
        trIdx = CVO.training(i);
        teIdx = CVO.test(i);
        Namb = ALL_Namb(trIdx,:);
        Amb  = ALL_Amb(trIdx,:);
        TS_Namb = ALL_Namb(teIdx,:);
        TS_Amb  = ALL_Amb(teIdx,:);

%         Namb = mB2(:,1:p);
%         Amb  = mB2(:,p+1:end);
%         TS_Namb = mB1(:,1:p);
%         TS_Amb  = mB1(:,p+1:end);

        pTrainGPU;
        %RS = [RS; V2(TS_Namb+1), num2str(KK), V2(TS_Amb+1)];
        %RS(str2double(RS(:,p+1))==1,:) = [];
        RS(teIdx,1) = gather(KK);

    %     figure;
    %     plot(mX(:,1),mX(:,2),'k.');
    %     hold on;
    %     A = unique(Amb(:));
    %     plot(mX(A,1),mX(A,2),'b.');
    %     A = unique(Amb(:,1));
    %     plot(mX(A,1),mX(A,2),'r.');
    %     title(num2str(sum(sum(isnan(mX)==1))));

%         fprintf('%d.fold p %d N %d TR %2.2f TS %2.2f\n',i,p,N,100*Ctr(i),100*Cts(i));
    end
    fprintf('%d p %d N %d TR %2.2f TS %2.2f\n',tekrar,p,N,100*mean(Ctr),100*mean(Cts));
    eval(['KK' num2str(tekrar) '=RS;']);
    save(['KKtestP' num2str(p) 'N' num2str(N) '.mat'],['KK' num2str(tekrar)],'-append');
end